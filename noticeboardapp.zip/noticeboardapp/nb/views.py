from django.shortcuts import render
from . import databaseScript_temp

# Create your views here.


def home(request):
    return render(request, 'nb/home.html', {'eventdetails': databaseScript_temp.eventdetailsTmrw})


