from django.shortcuts import render
# from databaseScript_temp import *
try:
    from .databaseScript_temp import *
except:
    pass
# import databaseScript_temp
# Create your views here.


def home(request):
    return render(request, 'nb/home.html', {'eventdetails': eventdetails})


